# software-decard · 软件去卡密自用版 Skill

把**自己购买的** Electron 桌面软件改造成免卡密/免激活码的"自用版"：不改软件本体一个字节，而是写一个"诚实的替身授权模块（activation 替身）"换掉授权校验模块，让软件本地判定"已激活"。

## 这个 Skill 是什么

一套可复用的方法论 + 操作手册 + AI 提示词，核心资产来自：

- 一份 45 页《软件去卡密完全实战教程》（某招聘软件案例，全文脱敏）
- 两场共 11 小时 17 分的实战会话蒸馏（40+ 条与 60+ 条经验）

主要内容：

| 文件 | 内容 |
|---|---|
| `SKILL.md` | 主流程：红线 → 识别信号 → 软件类型决策树（含原生模块可选工具箱）→ 九步操作 → 12 项验证矩阵 → Top10 坑 → 子智能体分工 |
| `references/prompts.md` | 9 段可直接粘贴给 AI 的分步提示词（15.0–15.8）+ 探针/挂钩/替身/编译全套代码模板 |
| `references/pitfalls.md` | 40+ 条踩坑全表，按六大主题分组 + 界面注入专项（现象 → 根因 → 解法） |
| `references/remote-ops.md` | 远程操控 Windows 手册（三种环境判断；UU远程端口映射 + SSH 隧道 + sshd 修复 + EncodedCommand 黄金范式） |
| `references/ui-patch.js` / `references/ui-patch.css` | 部署附件 ui-patch 模板（JS 常量区已参数化 + 配套样式），第 7 步随 app 目录一起部署 |
| `references/ui-signature.user.js` | 网页版油猴脚本模板（与 ui-patch 同源的网页场景版） |
| `assets/` | 部署附件素材（图片及 base64 文本） |
| `VERIFY-REPORT.md` | 白纸实测报告：独立智能体仅凭本 Skill 在真实 Windows 环境完成侦察与验证的执行记录，含 6 条文档缺陷的修复留痕与界面注入层验证追加 |

> **从技能市场下载的压缩包若只含 .md 文档**（部分平台限制文件类型）：ui-patch 部署附件（JS/CSS）、油猴模板、二维码素材等二进制文件的完整版，请从 [GitHub 仓库](https://github.com/simonsxxs/software-decard) 或 [Gitee 镜像](https://gitee.com/simonsxx/software-decard) 获取。

## 边界（务必阅读）

- **仅限自购软件自用**：前提是你已购买该软件的授权。
- **绝不分发**：改造产物只允许在你自己的电脑上运行。"自用版"不是"破解版"，改造别人的软件再分发是侵犯著作权。
- **不伪造签名**：不碰作者 RSA 私钥，不生成假的"服务器已激活"凭证，不冒充实名认证。
- **不帮他人绕过付费**：本 Skill 不服务"破解别人软件"的需求。
- **产物界面署名**：产物界面默认附带技能作者署名与联系方式（右下角"加入社区"入口），可在 ui-patch 配置中替换为你自己的信息或关闭。

核心思想一句话：**不猜、不硬刚加密、不动别人的东西，只做一个诚实的替身。**

## 使用方法

把本目录放入你的 AI 工具的 skills 目录（如 `~/.agents/skills/`），当对话中出现"去掉自购软件的卡密/激活码校验、Electron 授权绕过自用、activation 替身模块、jsc 字节码、app 目录部署"等触发词时，Agent 会自动加载本 Skill 并按 `SKILL.md` 的流程执行。

---

## 署名

> 作者：simon，一个不懂代码的 AI 极客
> 微信交流群：`simonsxxs`
> GitHub：https://github.com/simonsxxs
> Gitee：https://gitee.com/simonsxx
